package com.baeldung.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserBodyValues {
    private double kilogram;
    private double centimeter;
    private Integer intValue;
}