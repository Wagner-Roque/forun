package com.baeldung.entity;

public class ElectricCar extends Car {
}
