package com.baeldung.entity;

public class BioDieselCar extends Car {
}
