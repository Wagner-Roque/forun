package com.baeldung.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserBodyImperialValuesDTO {
    private int inch;
    private int pound;
    private String strValue;
}