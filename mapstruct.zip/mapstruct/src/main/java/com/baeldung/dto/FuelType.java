package com.baeldung.dto;

public enum FuelType {
    ELECTRIC, BIO_DIESEL
}
