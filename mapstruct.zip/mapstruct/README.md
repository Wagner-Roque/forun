## MapStruct

This module contains articles about MapStruct.

### Relevant Articles:

- [Quick Guide to MapStruct](https://www.baeldung.com/mapstruct)
- [Custom Mapper with MapStruct](https://www.baeldung.com/mapstruct-custom-mapper)
- [Using Multiple Source Objects with MapStruct](https://www.baeldung.com/mapstruct-multiple-source-objects)
- [Ignoring Unmapped Properties with MapStruct](https://www.baeldung.com/mapstruct-ignore-unmapped-properties)
